package _main;

import view_control.MainMenu;

public class Main {
	public static void main(String[] args) {
		MainMenu.main(null);
	}
}
