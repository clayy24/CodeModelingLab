package control_prog_lang;
/**
 * Write a description of class CSharp here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CSharp extends ProgLangAttributes 
{
	public CSharp() {
		ProgLang="C#";
		BirthDate="2000";
		Creator="Anders Hejlsberg, Microsoft";
		Owner="Microsoft";
		ReasonForDemand="Websites, Cool language for gaming using Unity";
		GitHubUsageRank="Rank: 7";
		KeyCompanies="Microsoft";
		AvgSalary="$110,000";
		ide="Visual Studio, JetBrains, Rider";
		frameworks="Unity Game Engine, .Net, APS.Net^";	
    }
}
