package control_prog_lang;
/**
 * Write a description of class Python here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Python extends ProgLangAttributes
{
    public Python() {
		ProgLang="Python";
		BirthDate="1989";
		Creator="Guido van Rossum, CWI";
		Owner="Open Source";
		ReasonForDemand="Data Science, Stats, Analytics, AI";
		GitHubUsageRank="Rank: 2";
		KeyCompanies="Youtube, Instagram, Pinterest, Mozilla, Spotify";
		AvgSalary="$116,000";
		ide=",Pycharm, Eclipse, Visual Studio";
		frameworks="Django, Pyramid, Turbo Gear";
    }
}
