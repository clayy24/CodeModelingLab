package control_prog_lang;
/**
 * Write a description of class Java here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Java extends ProgLangAttributes
{
	public Java() {
		ProgLang="Java";
		BirthDate="Early 1990s";
		Creator="James Gosling, Sun Micro Systems";
		Owner="Oracle";
		ReasonForDemand="Platform Port (WORA), 3 billion devices";
		GitHubUsageRank="Rank: 3";
		KeyCompanies="Amazon, Twitter, Google";
		AvgSalary="$100,000";
		ide="IntelliJ IDEA, NetBeans, Eclipse";
		frameworks="Spring, Struts, Hibernate";
	}
	
}
