package control_prog_lang;
/**
 * Write a description of class Ruby here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ruby extends ProgLangAttributes
{
     public Ruby() {
 		ProgLang="Ruby";
		BirthDate="Mid 1990s";
		Creator="Yukihiro \"Matz\" Matsumoto";
		Owner="Open Source, Ruby License";
		ReasonForDemand="Websites, Apps";
		GitHubUsageRank="Rank: 11";
		KeyCompanies="Airbnb, Github";
		AvgSalary="$123,000";
		ide="RubyMine, Eclipse, Komodo, NetBeans";
		frameworks="Rails, JRuby";
     }
}
