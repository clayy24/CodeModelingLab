package control_prog_lang;
/**
 * Write a description of class Swift here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Swift extends ProgLangAttributes
{
    public Swift() {
		ProgLang="Swift";
		BirthDate="2014";
		Creator="Apple";
		Owner="Open Source";
		ReasonForDemand="Friendly to use Apple iOS development";
		GitHubUsageRank="Rank: 14";
		KeyCompanies="Apple";
		AvgSalary="$115,000.00";
		ide="Xcode";
		frameworks="Cocoa";
    }
}
